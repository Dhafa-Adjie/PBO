/**
 * 
 */
/**
 * 
 */
module matchButton_byMDA_2327250081 {
	requires java.desktop;
}