/**
 * 
 */
/**
 * 
 */
module dreamBox_MDA_2327250081 {
	requires java.desktop;
}